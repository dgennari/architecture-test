# Procura um caracter vogal em uma Stream

- Este método deve retornar o primeiro caractere Vogal, após uma consoante, onde a mesma é antecessora a uma vogal e que não se repita no resto da stream.
- Como contrato, a interface Stream possui os métodos getNext() e hasNext()  

## Pré-requisitos
Maven 3
Java 8
Junit 4.12


## Premissas

A premissa do projeto é que a entrada seja convertida em uma estrutra de dados que implemente a interface stream fornecida.

public interface Stream {

    char getNext();
    boolean hasNext();

}


Uma chamada para ```hasNext()``` irá retornar se a stream ainda contêm caracteres para processar.

Uma chamada para ```getNext()``` irá retornar o próximo caracter a ser processado na stream.

Não será possível reiniciar o fluxo da leitura da stream.

Não poderá ser utilizado nenhum framework Java, apenas código nativo.



## Desenvolvimento:
 A estratégia utilizada para a resolução do problema foi a seguinte:

    * Um *LinkedHashMap* que garante que uma vogal se repetiu mais de uma vez na stream que mantém a ordem de inserção.
    * No retorno, pega-se o primeiro valor inserido que não se repete ou lança uma exception.

## Testes:

```mvn test```

 - Cenário 1 (aAbBABacafj): String que não contém o caractere que atendam as regras especificadas. Neste cenário é validado se o método lança a exception.

 - Cenário 2 (aAbBABacafe): String que contém um caractere que atende as regras especificadas. Neste cenário é validado que a vogal esperada é a vogal encontrada.

 - Cenário 3 (aAbBABadicafe): String que contém mais de um caractere que atende as regras especificadas. Neste cenário é validado que a vogal esperada é a primeira vogal encontrada.
 
 - Cenário 4 (null): String nula deve lançar uma exceção .
 
 - Cenário 5 (testefgh): String que testa o método hasNext quando não ha mais caracteres a percorrer.
 
 - Cenário 6 (abc): String que tests o método getNext e deve lançar uma exceção StringIndexOutOfBoundsException.

