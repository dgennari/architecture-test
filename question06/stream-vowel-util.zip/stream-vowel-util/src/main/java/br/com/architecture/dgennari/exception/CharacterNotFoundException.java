package br.com.architecture.dgennari.exception;

/**
 * Nome: Daniel Gennari Proposito: Prova Test Arquiteto Parametro de compilacao:
 * -d
 *
 * @author: Architecture Copyright (c) 25/09/2017
 * @version 1.0
 * @return: NA.
 * @throws: NA.
 * @see: NA. &lt;p&gt;Maintenance Record: &lt;li&gt;Date : &lt;/li&gt;
 *       &lt;li&gt;Autor: &lt;/li&gt; &lt;li&gt;Responsible: &lt;/li&gt;
 *       &lt;/p&gt;
 * 
 */
public class CharacterNotFoundException extends RuntimeException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2657153588895734679L;

	/**
	 * Default Constructor
	 * New instance object CharacterNotFoundException
	 */
	public CharacterNotFoundException() {
		super(
				"Vogal, após uma consoante, onde a mesma é antecessora não encontrada nesta Stream");
	}
}
