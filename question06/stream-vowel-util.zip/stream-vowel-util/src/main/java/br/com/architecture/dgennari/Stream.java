package br.com.architecture.dgennari;

/**
 * Nome: Daniel Gennari Proposito: Prova Test Arquiteto Parametro de compilacao:
 * -d
 *
 * @author: Architecture Copyright (c) 25/09/2017
 * @version 1.0
 * @return: NA.
 * @throws: NA.
 * @see: NA. &lt;p&gt;Maintenance Record: &lt;li&gt;Date : &lt;/li&gt;
 *       &lt;li&gt;Autor: &lt;/li&gt; &lt;li&gt;Responsible: &lt;/li&gt;
 *       &lt;/p&gt;
 * 
 */
public interface Stream {

	/**
	 * Name: next
	 * @exception CharacterNotFoundException
	 * @return Retornar o proximo caracter a ser processado na stream
	 */
	char getNext();

	/**
	 * Name: hasNext
	 * @exception CharacterNotFoundException
	 * @return retornar true se a stream ainda contem caracteres para processar, senao false
	 */
	boolean hasNext();
}