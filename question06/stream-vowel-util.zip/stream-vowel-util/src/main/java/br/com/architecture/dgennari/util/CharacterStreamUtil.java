package br.com.architecture.dgennari.util;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import br.com.architecture.dgennari.Stream;
import br.com.architecture.dgennari.exception.CharacterNotFoundException;

/**
 * Nome: Daniel Gennari Proposito: Prova Test Arquiteto Parametro de compilacao:
 * -d
 *
 * @author: Architecture Copyright (c) 25/09/2017
 * @version 1.0
 * @return: NA.
 * @throws: NA.
 * @see: NA. &lt;p&gt;Maintenance Record: &lt;li&gt;Date : &lt;/li&gt;
 *       &lt;li&gt;Autor: &lt;/li&gt; &lt;li&gt;Responsible: &lt;/li&gt;
 *       &lt;/p&gt;
 * 
 */
public class CharacterStreamUtil {

	/**
	 * Name: Execute.
	 * 
	 * @param stream
	 *            the stream to be evaluated
	 * @return the char the current char being evaluated
	 * @throws CharacterNotFoundException
	 *             the character not found exception
	 */
	public static char execute(Stream stream) throws CharacterNotFoundException {
		final LinkedHashMap<Character, Boolean> characters = new LinkedHashMap<Character, Boolean>();
		char lastCharacterinStream = 0, nextCharacterToLast = 0;
		while (stream.hasNext()) {
			char currentChar = stream.getNext();
			if (isVowel(currentChar) && !isVowel(lastCharacterinStream)
					&& isVowel(nextCharacterToLast)) {
				if (characters.containsKey(currentChar))
					characters.put(currentChar, false);
				else
					characters.put(currentChar, true);
			}
			nextCharacterToLast = lastCharacterinStream;
			lastCharacterinStream = currentChar;
		}
		return characters.entrySet().stream().filter(Entry::getValue)
				.findFirst().map(Map.Entry::getKey)
				.orElseThrow(CharacterNotFoundException::new);
	}

	/**
	 * Name: isVowel.
	 * 
	 * @param Character
	 *            to be evaluated if it is a vowel or not
	 * @return Return true, if is vowel
	 */
	private static boolean isVowel(char characterVowel) {
		final String vowels = "aeiouAEIOU";
		return vowels.indexOf(characterVowel) >= 0;
	}

}
