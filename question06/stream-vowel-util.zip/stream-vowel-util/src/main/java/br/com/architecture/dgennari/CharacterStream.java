package br.com.architecture.dgennari;

/**
 * Nome: Daniel Gennari Proposito: Prova Test Arquiteto Parametro de compilacao:
 * -d
 *
 * @author: Architecture Copyright (c) 25/09/2017
 * @version 1.0
 * @return: NA.
 * @throws: NA.
 * @see: NA. &lt;p&gt;Maintenance Record: &lt;li&gt;Date : &lt;/li&gt;
 *       &lt;li&gt;Autor: &lt;/li&gt; &lt;li&gt;Responsible: &lt;/li&gt;
 *       &lt;/p&gt;
 * 
 */
public class CharacterStream implements Stream {

	/** The stream to be evaluated. */
	private String stream;

	/** The index to use in array. */
	private Integer index;

	/** The current char being evaluated. */
	private Character currentChar;

	/**
	 * Default Constructor Instantiates a new character stream
	 * 
	 * @param stream
	 *            the stream to be evaluated
	 */
	public CharacterStream(String stream) {
		if (stream == null) {
			throw new IllegalArgumentException(
					"Stream inválido. Digite novamente.");
		}
		this.stream = stream;
		this.index = -1;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.architecture.dgennari.Stream#next()
	 */
	@Override
	public char getNext() {
		index++;
		currentChar = stream.charAt(index);
		return currentChar;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.architecture.dgennari.Stream#hasNext()
	 */
	@Override
	public boolean hasNext() {
		try {
			Character nextChar = stream.charAt(index + 1);
			if (nextChar != null)
				return true;
			else
				return false;
		} catch (Exception ex) {
			return false;
		}
	}

}
