package br.com.architecture.dgennari;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import br.com.architecture.dgennari.exception.CharacterNotFoundException;
import br.com.architecture.dgennari.util.CharacterStreamUtil;

/**
 * Nome: Daniel Gennari Proposito: Prova Test Arquiteto Parametro de compilacao:
 * -d
 *
 * @author: Architecture Copyright (c) ${year}
 * @version 1.0
 * @return: NA.
 * @throws: NA.
 * @see: NA. &lt;p&gt;Maintenance Record: &lt;li&gt;Date : &lt;/li&gt;
 *       &lt;li&gt;Autor: &lt;/li&gt; &lt;li&gt;Responsible: &lt;/li&gt;
 *       &lt;/p&gt;
 * 
 */
public class CharacterStreamlTest {
	
	@Test(expected = CharacterNotFoundException.class)
	public void testInputWithoutValidResult() throws Exception {
		String text = "aAbBABacafj";
		Stream stream = new CharacterStream(text);
		Character expResult = 'i';
		Character result = CharacterStreamUtil.execute(stream);
		assertEquals(expResult, result);
	}
	
	@Test
	public void testInputCharWithOneValidResult() throws Exception {
		String text = "aAbBABacafe";
		Stream stream = new CharacterStream(text);
		Character expResult = 'e';
		Character result = CharacterStreamUtil.execute(stream);
		assertEquals(expResult, result);
	}

	@Test
	public void testInputWithTwoValidResults() throws Exception {
		String text = "aAbBABadicafe";
		Stream stream = new CharacterStream(text);
		Character expResult = 'i';
		Character result = CharacterStreamUtil.execute(stream);
		assertEquals(expResult, result);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testShouldThrowExceptionWhenInvalidStream() {
		new CharacterStream(null);
	}

	@Test
	public void testShouldNotifyNoMoreCharactersToProcess() {
		Stream stream = new CharacterStream("testefgh");
		while (stream.hasNext()) {
			stream.getNext();
		}
		assertThat(stream.hasNext(), is(equalTo(false)));
	}

	@Test(expected = StringIndexOutOfBoundsException.class)
	public void testShouldThrowExceptionWhenInvalidStreamState() {
		Stream stream = new CharacterStream("abc");
		for (int i = 0; i < 5; i++) {
			stream.getNext();
		}
	}

}
